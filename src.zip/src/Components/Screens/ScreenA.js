
import React , { Component } from 'react';
import { NavLink } from 'react-router-dom';
import keyCode from '../../common/KeyMap'
import ScreenManager from '../../common/ScreenManager'

 

class ScreenA extends React.Component {
   
constructor(props){
    super(props)
    this.onScreenAction =  this.onScreenAction.bind(this);
    this.state ={
        nav:0
    }
    this.keyPress="";
}

componentDidUpdate(prevProps, prevState, snapshot){
    //console.log("Screen A Key Change")
    if(prevState.nav === this.state.nav){
         this.handleKeyA( this.keyPress);
    }
}

componentDidMount(){
    console.log(ScreenManager);
    ScreenManager.screenManagerInit(this);
}

_handleKeyDownScreen(e){
    console.log("Handle Screen Key:"+e.keyCode)
    this.keyPress = e.keyCode;
    this.handleKeyA(e.keyCode)   
  }

handleKeyA = (key) =>{
  if(keyCode.VK_LEFT ===key || keyCode.VK_RIGHT ===key){  
          //  console.log("ScreenA key Code "+ key)
            if(this.state.nav===2){
               this.setState({nav:0})
            }else{
                this.setState((prevState)=>{
                        return {
                            nav:prevState.nav+1
                        }
                })
            }
    }
    if(keyCode.VK_ENTER ===key ){  
        if(this.state.nav===1){
            this.handleClick();
        }

        if(this.state.nav===0){
           this.props.history.push("/screenC")
        }

        if(this.state.nav===2){
            this.props.history.goBack()
         }
    } 
}

onScreenAction = ()=>{
        alert("On Screen Action")
    }   

handleBack(){
        alert("ppp")
        this.props.history.goBack()
    }

handleClick = ()=>{
    alert("Screen Indivisuial : Screen C");
}

render(){
        return (<div>
            <header className="App-header">
                <h1 className="App-title">AScreen Name <span>{this.props.match.params.screenName}</span></h1>
            </header>
            <NavLink className={this.state.nav===0 ? "selectedAtt":"non-sel"} to="/screenC" >Screen C </NavLink>
            <a  className={this.state.nav===1 ? "selectedAtt":"non-sel"} onClick={this.handleClick.bind(this)} >Click to See Action</a>
            <span className={this.state.nav===2 ? "selectedAtt":"non-sel"}>
                {ScreenManager.backButton(this)}
            </span>
        </div>);
    }

};


export default  ScreenManager(ScreenA,ScreenA)  ;

