import React from 'react';
import { NavLink } from 'react-router-dom';
import ScreenManager from '../../common/ScreenManager'




class GeneralScreen extends ScreenManager{



    render(){
        const selectedLink = {
            fontWeight: 'bold',
            color: 'red'
        }
        return (<div>
            <header className="App-header">
                <h1 className="App-title">Screen Name <span>{this.props.match.params.screenName}</span></h1>
            </header>
            <p className="App-intro"></p>
            {this.props.history.location.key && <a onClick={() => this.props.history.goBack()} > Back</a>}
            {!this.props.history.location.key && <div> <NavLink tabIndex="0" activeStyle={selectedLink} to="/screenA" >Screen A</NavLink> 
                                                 <NavLink  activeStyle={selectedLink} to="/screenB">Screen B </NavLink> </div>}
    
    
        </div>);
    }

    
}



export default GeneralScreen;

