import React , { Component }  from 'react';
import { NavLink } from 'react-router-dom';
// class ScreenManager extends React.Component {
   
//     constructor(props){
//         super()
//     }
//     static  screenManagerInit(self){
//         console.log("ScreenMana");
//         document.addEventListener("keydown", ScreenManager._handleKeyDown.bind(self));
//     }


//     static componentDidMount(){
//     //    console.log(this.props) 
//     //    const nextScreen = this.props.location.pathname==="/"?"None":this.props.location.pathname;
//     //    const previousScreen = "Home";
//     //    if(this.props.location.state){
//     //     this.props.location.state.prevPath===undefined ||  this.props.location.state.prevPath ==="/" ?"Home":this.props.location.state.prevPath;
//     //    }
//     //    console.log("Previous Screen:" + previousScreen);      
//     //    console.log('Current Screen:'+ nextScreen);
//     }
    
//     static _handleKeyDown  (event) {
//         console.log("ScreenManagerNew:"+event.keyCode);
//         if(this._handleKeyDownScreen){
//             this._handleKeyDownScreen(event)
//         }
    
//      }
    
//      static backButton(self){
//         const BackButton = self.props.history.location.key && <a   onClick={ self.handleBack.bind(self)} > Back</a>;
//         return BackButton;
//      } 

    
//   }


 var ScreenManager = (ComposedComponent,Screen) => class extends Component {
    constructor(props) {
        super(props);
        this.state = {pressed: false};
        this.handlePress = this.handlePress.bind(this);
    }
  
    componentWillMount(){
      document.addEventListener("keydown",this._handleKeyDown);
    }
  
    _handleKeyDown (e){
             console.log("ScreenManagerNew:"+e.keyCode);
             Screen.handleScreenKey(e.keyCode)
           }
  
    handlePress() {
        this.setState({pressed: !this.state.pressed});
    }
  
    render() {
        return <ComposedComponent {...this.props} handlePress={this.handlePress} data={this.state.pressed} />;
    }
  };


  export default ScreenManager