import React, { Component } from 'react';
import { BrowserRouter as Router, Route, NavLink ,Switch } from "react-router-dom";
import GeneralScreen from './Components/Screens/GeneralScreen'
import ScreenA from './Components/Screens/ScreenA'


import './App.css';

class App extends Component {


  render() {
    return (
      <Router>
          <Switch>
            <Route exact path="/"   component={GeneralScreen}  />
            <Route exact path="/screenA"   component={ScreenA}  />
          </Switch> 
      </Router>
    );
  }
}

export default App;
